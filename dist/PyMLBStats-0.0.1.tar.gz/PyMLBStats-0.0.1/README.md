# PyBaseball

This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.

So there's not really a good documentation for the statsapi or really a good wrapper so I'm making once
Right now i have the main get function and working on the paths

# Working functions

* `latestGamePack()`

* `getAttendance()`

* `getPlayer()`

* `get()`

# Copyright
This package and its author are not affiliated with MLB or any MLB team. This API wrapper interfaces with MLB's Stats API. Use of MLB data is subject to the notice posted at http://gdx.mlb.com/components/copyright.txt.

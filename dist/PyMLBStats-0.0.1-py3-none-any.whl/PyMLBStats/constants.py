BASE_URL = "http://statsapi.mlb.com/api/v1/"
